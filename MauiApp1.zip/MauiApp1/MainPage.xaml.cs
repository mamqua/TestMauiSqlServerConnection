﻿using Java.Net;
using Microsoft.Data.SqlClient;

namespace MauiApp1;

public partial class MainPage : ContentPage
{
	int count = 0;

	public MainPage()
	{
		InitializeComponent();
	}

	private void OnCounterClicked(object sender, EventArgs e)
	{
        string str = "Persist Security Info=False;User ID=proteus;Password=******;Data Source=serverSql;Initial Catalog=DBMadre;Connect Timeout=120; Max Pool Size=200; MultipleActiveResultSets=True;";
        string qs = "SELECT * FROM dbo.Agenti;";
        using (SqlConnection connection = new SqlConnection(str))
        {
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand(qs, connection);
                command.ExecuteNonQuery();
            }
            catch (Exception rt)
            {
                string ff;
                ff = rt.Message;
            }

        }
    }
}

